package com.demo.quizapp.Dao;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.quizapp.entity.Question;

@Repository
public interface QuestionDAO extends JpaRepository<Question,Integer> {

	List<Question> findByCategory(String category);
	List<Question> findByDifficultyLevel(String difficultyLevel);

	
}
