package com.demo.quizapp.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.quizapp.Dao.QuestionDAO;
import com.demo.quizapp.entity.Question;

import jakarta.transaction.Transactional;

@Service
public class QuestionService {
	@Autowired
	QuestionDAO questionDao;
	public List<Question> getAllQuestions() {
		//System.out.println("Number of questions retrieved: " + all.size());
		List<Question> all = questionDao.findAll();
		return all;
	}
	
	public int getQuestionCount() {
		int count = (int) questionDao.count();
		return count;
		
	}

	public Question getQuestionById(Integer id) {
	    return questionDao.findById(id)
	        .orElseThrow(() -> new NoSuchElementException("Question not found with id: " + id));
	}

	public List<Question> getQuestionByCategory(String category) {
		List<Question> byCategory = questionDao.findByCategory(category);
		
		return byCategory;
	}

	public List<Question> getQuestionsByDifficultyLevel(String difficultyLevel) {
		List<Question> byDifficultyLevel = questionDao.findByDifficultyLevel(difficultyLevel);
		return byDifficultyLevel;
	}
	
	@Transactional
	public Question addQuestion(Question question) {
		
		return questionDao.save(question);
		
		
	}

	
	
	
	
	
	
	
	
	

}
