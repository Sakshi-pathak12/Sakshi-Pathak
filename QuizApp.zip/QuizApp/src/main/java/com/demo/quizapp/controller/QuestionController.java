package com.demo.quizapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.quizapp.Dao.QuestionDAO;
import com.demo.quizapp.Service.QuestionService;
import com.demo.quizapp.entity.Question;


@RestController
@RequestMapping("/question")
@CrossOrigin(origins = "*")
public class QuestionController {
	
	@Autowired
	QuestionService questionService;
	
	@Autowired 
	QuestionDAO questionDao;
	
	
	@GetMapping("/allquestions")
	public List<Question> getAllQuestions() {
		System.out.println("getting questions list");
		return questionService.getAllQuestions();
		//return "hello";
		
	}
	
	@GetMapping("/count")
	public int getQuestionCount() {
		return questionService.getQuestionCount();
		
	}
	
	@GetMapping("/byid/{id}")
	public Question getQuestionById(@PathVariable Integer id) {
	    return questionService.getQuestionById(id);
	}
	
	@GetMapping("/byCategory/{category}")
	public List<Question> getQuestionByCategory(@PathVariable String category) {
		return questionService.getQuestionByCategory(category);
		
	}
	
	@GetMapping("/buDifficultyLevel/{difficultyLevel}")
	public List<Question> getQuestionByDifficultyLevel(@PathVariable String difficultyLevel){
		return questionService.getQuestionsByDifficultyLevel(difficultyLevel);
		
	}
	
	//adding question by client 
//	@PostMapping("/addquestion")
//	public Question addQuestion(@RequestBody Question question) {
//		
//		return questionService.addQuestion(question);
//		
//	}
//	
	@PostMapping("/addquestion")
    public Question addQuestion1(@RequestBody Question question) {
        return questionDao.save(question);
    }
}
